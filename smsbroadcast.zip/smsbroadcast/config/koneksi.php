<?php
define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('DB', 'smsbroadcast');
$conn = new mysqli(HOST, USER, PASS, DB) or die('Connetion error to the database');
// if ($conn) {
//     echo "koneksi berhasil";
// } else {
//     echo "gagal";
// }
