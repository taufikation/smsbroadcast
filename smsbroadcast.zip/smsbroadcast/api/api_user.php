<?php
require_once('../config/koneksi.php');

function http_request($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}

$data = http_request("http://localhost/smsbroadcast/api_user.php");
$data = json_decode($data, TRUE);



if (isset($_POST['uuid']) && isset($_POST['no_terima']) && isset($_POST['teks'])) {
    $uuid    = $_POST['uuid'];
    $no_terima  = $_POST['no_terima'];
    $teks    = $_POST['teks'];

    $sql = $conn->prepare("INSERT INTO inbox (uuid, no_terima, teks) VALUES (?, ?, ?)");
    $sql->bind_param('sss', $uuid, $no_terima, $teks);
    $sql->execute();
    if ($sql) {
        //echo json_encode(array('RESPONSE' => 'SUCCESS'));
        header("location:../readapi/tampil.json");
    } else {
        echo json_encode(array('RESPONSE' => 'FAILED'));
    }
} else {
    echo "GAGAL";
}
